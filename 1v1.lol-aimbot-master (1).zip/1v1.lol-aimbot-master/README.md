# 1v1.lol-aimbot 

## Youtube Channel: HackerHansen 

### Video: https://youtu.be/WNaZm6CXWnQ 

This is a simple aimbot script coded in AHK. To run it, you must download autohotkey from https://www.autohotkey.com/ 

If it doesn't work, follow the steps in the video to make it work for you. 

Please don't use this in ranked/competitive matches. 
